(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.module = f()}})(function(){var define,module,exports;return (function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){

// This file is an automatically generated and should not be edited

'use strict';

const options = [{"name":"data","type":"Data"},{"name":"buildModel_variables_long_actor","title":"Actor","type":"Variable"},{"name":"buildModel_variables_long_time","title":"Time","type":"Variable"},{"name":"buildModel_variables_long_action","title":"Action","type":"Variable"},{"name":"buildModel_variables_long_order","title":"Order","type":"Variable"},{"name":"buildModel_variables_long_group","title":"Group","type":"Variable"},{"name":"buildModel_type","title":"Type","type":"List","options":[{"title":"Relative","name":"relative"},{"title":"Frequency","name":"frequency"},{"title":"Co-occurrence","name":"co-occurrence"}],"default":"relative"},{"name":"buildModel_scaling","title":"Scaling","type":"List","options":[{"title":"No scaling","name":"noScaling"},{"title":"MinMax","name":"minmax"},{"title":"Max","name":"max"},{"title":"Rank","name":"rank"}],"default":"noScaling"},{"name":"buildModel_show_matrix","title":"Show matrix","type":"Bool","default":false},{"name":"buildModel_threshold","title":"Threshold","type":"Integer","default":900},{"name":"buildModel_show_plot","title":"Show plot","type":"Bool","default":true},{"name":"buildModel_plot_cut","title":"Cut value","type":"Number","default":0,"min":0,"max":1},{"name":"buildModel_plot_min_value","title":"Minimum value","type":"Number","default":0.05,"min":0,"max":1},{"name":"buildModel_plot_edge_label_size","title":"Edge label size","type":"Number","default":1,"min":0,"max":10},{"name":"buildModel_plot_node_size","title":"Node size","type":"Number","default":1,"min":0,"max":2},{"name":"buildModel_plot_node_label_size","title":"Node label size","type":"Number","default":1,"min":0,"max":10},{"name":"buildModel_plot_layout","title":"Layout","type":"List","options":[{"title":"Circle","name":"circle"},{"title":"Spring","name":"spring"}]},{"name":"buildModel_show_histo","title":"Show histogram","type":"Bool","default":false},{"name":"buildModel_show_mosaic","title":"Show mosaic","type":"Bool","default":false},{"name":"buildModel_digits","title":"Digits","type":"Integer","default":1},{"name":"centrality_loops","title":"loops","type":"Bool","default":false},{"name":"centrality_normalize","title":"normalize","type":"Bool","default":false},{"name":"centrality_show_table","title":"Show table","type":"Bool","default":false},{"name":"centrality_show_plot","title":"Show plot","type":"Bool","default":false},{"name":"centrality_Betweenness","title":"Betweenness","type":"Bool","default":true},{"name":"centrality_BetweennessRSP","title":"BetweennessRSP","type":"Bool","default":false},{"name":"centrality_Closeness","title":"Closeness","type":"Bool","default":false},{"name":"centrality_ClosenessIn","title":"ClosenessIn","type":"Bool","default":false},{"name":"centrality_ClosenessOut","title":"ClosenessOut","type":"Bool","default":false},{"name":"centrality_Clustering","title":"Clustering","type":"Bool","default":false},{"name":"centrality_Diffusion","title":"Diffusion","type":"Bool","default":false},{"name":"centrality_InStrength","title":"InStrength","type":"Bool","default":true},{"name":"centrality_OutStrength","title":"OutStrength","type":"Bool","default":true},{"name":"community_methods","title":"Methods","type":"List","default":"spinglass","options":[{"name":"spinglass","title":"Spinglass"},{"name":"walktrap","title":"Walktrap"},{"name":"fast_greedy","title":"Fast greedy"},{"name":"label_prop","title":"Label Prop"},{"name":"infomap","title":"Infomap"},{"name":"edge_betweenness","title":"Edge betweenness"},{"name":"leading_eigen","title":"Leading eigen"}]},{"name":"community_gamma","title":"Gamma","type":"Integer","default":1,"min":0,"max":100},{"name":"community_show_table","title":"Show table","type":"Bool","default":false},{"name":"community_show_plot","title":"Show plot","type":"Bool","default":false},{"name":"cliques_size","title":"Size","type":"Integer","default":2,"min":2,"max":10},{"name":"cliques_threshold","title":"Threshold","type":"Number","default":0,"min":0,"max":1},{"name":"cliques_show_text","title":"Show Text","type":"Bool","default":false},{"name":"cliques_show_plot","title":"Show plot","type":"Bool","default":false},{"name":"cliques_plot_cut","title":"Cut value","type":"Number","default":0,"min":0,"max":1},{"name":"cliques_plot_min_value","title":"Minimum value","type":"Number","default":0,"min":0,"max":1},{"name":"cliques_plot_edge_label_size","title":"Edge label size","type":"Number","default":1,"min":0,"max":10},{"name":"cliques_plot_node_size","title":"Node size","type":"Number","default":1,"min":0,"max":2},{"name":"cliques_plot_node_label_size","title":"Node label size","type":"Number","default":1,"min":0,"max":10},{"name":"cliques_plot_layout","title":"Layout","type":"List","default":"circle","options":[{"title":"Circle","name":"circle"},{"title":"Spring","name":"spring"}]},{"name":"bootstrap_iteration","title":"Iteration","type":"Integer","default":1000,"min":0,"max":10000},{"name":"bootstrap_level","title":"Level","type":"Number","default":0.05,"min":0,"max":1},{"name":"bootstrap_method","title":"Method","type":"List","default":"stability","options":[{"title":"Stability","name":"stability"},{"title":"Threshold","name":"threshold"}]},{"name":"bootstrap_range_low","title":"Lower","type":"Number","default":0.75,"min":0,"max":10},{"name":"bootstrap_range_up","title":"Upper","type":"Number","default":1.25,"min":0,"max":10},{"name":"bootstrap_threshold","title":"Threshold","type":"Number","default":0.1,"min":0,"max":1},{"name":"bootstrap_show_text","title":"Show text","type":"Bool","default":false},{"name":"bootstrap_show_plot","title":"Show plot","type":"Bool","default":false},{"name":"bootstrap_plot_cut","title":"Cut value","type":"Number","default":0,"min":0,"max":1},{"name":"bootstrap_plot_min_value","title":"Minimum value","type":"Number","default":0.05,"min":0,"max":1},{"name":"bootstrap_plot_edge_label_size","title":"Edge label size","type":"Number","default":1,"min":0,"max":10},{"name":"bootstrap_plot_node_size","title":"Node size","type":"Number","default":1,"min":0,"max":2},{"name":"bootstrap_plot_node_label_size","title":"Node label size","type":"Number","default":1,"min":0,"max":10},{"name":"bootstrap_plot_layout","title":"Layout","type":"List","options":[{"title":"Circle","name":"circle"},{"title":"Spring","name":"spring"}]},{"name":"compare_model1","title":"Index of the model A","type":"Integer","default":1,"min":1},{"name":"compare_model2","title":"Index of the model B","type":"Integer","default":2,"min":1},{"name":"compare_show_text","title":"Show text","type":"Bool","default":false},{"name":"compare_show_plot","title":"Show compare plot","type":"Bool","default":false},{"name":"compare_show_TNAplot","title":"Show compare TNA plot","type":"Bool","default":false},{"name":"compare_TNAPlot_type","title":"Type","type":"List","default":"heatmap","options":[{"title":"Heatmap","name":"heatmap"},{"title":"Scatterplot","name":"scatterplot"},{"title":"Centrality heatmap","name":"centrality_heatmap"},{"title":"Weight density","name":"weight_density"}]},{"name":"compare_TNAPlot_population","title":"Population","type":"List","default":"difference","options":[{"title":"Model A","name":"x"},{"title":"Model B","name":"y"},{"title":"Difference","name":"difference"}]},{"name":"compare_TNAPlot_method","title":"Method","type":"List","default":"pearson","options":[{"title":"Pearson","name":"pearson"},{"title":"Kendall","name":"kendall"},{"title":"Spearman","name":"spearman"},{"title":"Distance","name":"distance"}]},{"name":"permutation_show_text","title":"Show text","type":"Bool","default":false},{"name":"permutation_show_plot","title":"Show plot","type":"Bool","default":false},{"name":"permutation_iter","title":"Iter","type":"Integer","default":1000,"min":1},{"name":"permutation_paired","title":"Paired","type":"Bool","default":false},{"name":"permutation_level","title":"Level","type":"Number","default":0.05,"min":0,"max":1}];

const view = function() {
    
    this.handlers = { }

    View.extend({
        jus: "3.0",

        events: [

	]

    }).call(this);
}

view.layout = ui.extend({

    label: "Group TNA",
    jus: "3.0",
    type: "root",
    stage: 0, //0 - release, 1 - development, 2 - proposed
    controls: [
		{
			type: DefaultControls.VariableSupplier,
			typeName: 'VariableSupplier',
			persistentItems: false,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "buildModel_variables_long_time",
							isTarget: true,
							maxItemCount: 1
						}
					]
				},
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "buildModel_variables_long_action",
							isTarget: true,
							maxItemCount: 1
						}
					]
				},
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "buildModel_variables_long_actor",
							maxItemCount: 1,
							isTarget: true
						}
					]
				},
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "buildModel_variables_long_order",
							maxItemCount: 1,
							isTarget: true
						}
					]
				},
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "buildModel_variables_long_group",
							maxItemCount: 1,
							isTarget: true
						}
					]
				}
			]
		},
		{
			type: DefaultControls.LayoutBox,
			typeName: 'LayoutBox',
			stretchFactor: 1,
			style: "inline",
			controls: [
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					stretchFactor: 1,
					controls: [
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Type",
							controls: [
								{
									type: DefaultControls.RadioButton,
									typeName: 'RadioButton',
									name: "buildModel_type_relative",
									optionName: "buildModel_type",
									optionPart: "relative"
								},
								{
									type: DefaultControls.RadioButton,
									typeName: 'RadioButton',
									name: "buildModel_type_frequency",
									optionName: "buildModel_type",
									optionPart: "frequency"
								},
								{
									type: DefaultControls.RadioButton,
									typeName: 'RadioButton',
									name: "buildModel_type_co_occurrence",
									optionName: "buildModel_type",
									optionPart: "co-occurrence"
								}
							]
						},
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Parameters",
							controls: [
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "buildModel_show_matrix",
									label: "Show matrix"
								},
								{
									type: DefaultControls.TextBox,
									typeName: 'TextBox',
									name: "buildModel_threshold",
									format: FormatDef.number
								}
							]
						}
					]
				},
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					stretchFactor: 1,
					controls: [
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Scaling",
							controls: [
								{
									type: DefaultControls.RadioButton,
									typeName: 'RadioButton',
									name: "buildModel_scaling_noScaling",
									optionName: "buildModel_scaling",
									optionPart: "noScaling"
								},
								{
									type: DefaultControls.RadioButton,
									typeName: 'RadioButton',
									name: "buildModel_scaling_minmax",
									optionName: "buildModel_scaling",
									optionPart: "minmax"
								},
								{
									type: DefaultControls.RadioButton,
									typeName: 'RadioButton',
									name: "buildModel_scaling_max",
									optionName: "buildModel_scaling",
									optionPart: "max"
								},
								{
									type: DefaultControls.RadioButton,
									typeName: 'RadioButton',
									name: "buildModel_scaling_rank",
									optionName: "buildModel_scaling",
									optionPart: "rank"
								}
							]
						}
					]
				}
			]
		},
		{
			type: DefaultControls.LayoutBox,
			typeName: 'LayoutBox',
			stretchFactor: 1,
			style: "inline",
			controls: [
				{
					type: DefaultControls.CollapseBox,
					typeName: 'CollapseBox',
					label: "Plot settings",
					margin: "large",
					collapsed: true,
					stretchFactor: 1,
					style: "inline",
					controls: [
						{
							type: DefaultControls.LayoutBox,
							typeName: 'LayoutBox',
							stretchFactor: 1,
							controls: [
								{
									type: DefaultControls.Label,
									typeName: 'Label',
									label: "TNA Model",
									controls: [
										{
											type: DefaultControls.CheckBox,
											typeName: 'CheckBox',
											name: "buildModel_show_plot",
											label: "Show model",
											controls: [
												{
													type: DefaultControls.TextBox,
													typeName: 'TextBox',
													name: "buildModel_plot_cut",
													format: FormatDef.number,
													enable: "(buildModel_show_plot)"
												},
												{
													type: DefaultControls.TextBox,
													typeName: 'TextBox',
													name: "buildModel_plot_min_value",
													format: FormatDef.number,
													enable: "(buildModel_show_plot)"
												},
												{
													type: DefaultControls.TextBox,
													typeName: 'TextBox',
													name: "buildModel_plot_edge_label_size",
													format: FormatDef.number,
													enable: "(buildModel_show_plot)"
												},
												{
													type: DefaultControls.TextBox,
													typeName: 'TextBox',
													name: "buildModel_plot_node_size",
													format: FormatDef.number,
													enable: "(buildModel_show_plot)"
												},
												{
													type: DefaultControls.TextBox,
													typeName: 'TextBox',
													name: "buildModel_plot_node_label_size",
													format: FormatDef.number,
													enable: "(buildModel_show_plot)"
												},
												{
													type: DefaultControls.ComboBox,
													typeName: 'ComboBox',
													name: "buildModel_plot_layout",
													enable: "(buildModel_show_plot)"
												}
											]
										}
									]
								}
							]
						},
						{
							type: DefaultControls.LayoutBox,
							typeName: 'LayoutBox',
							stretchFactor: 1,
							controls: [
								{
									type: DefaultControls.Label,
									typeName: 'Label',
									label: "Histogram plot",
									controls: [
										{
											type: DefaultControls.CheckBox,
											typeName: 'CheckBox',
											name: "buildModel_show_histo"
										}
									]
								}
							]
						},
						{
							type: DefaultControls.LayoutBox,
							typeName: 'LayoutBox',
							stretchFactor: 1,
							controls: [
								{
									type: DefaultControls.Label,
									typeName: 'Label',
									label: "Mosaic Plot",
									controls: [
										{
											type: DefaultControls.CheckBox,
											typeName: 'CheckBox',
											name: "buildModel_show_mosaic",
											enable: "(buildModel_type_frequency || buildModel_type_co_occurrence)",
											controls: [
												{
													type: DefaultControls.TextBox,
													typeName: 'TextBox',
													name: "buildModel_digits",
													format: FormatDef.number,
													enable: "(buildModel_show_mosaic)"
												}
											]
										}
									]
								}
							]
						}
					]
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Centrality",
			margin: "large",
			stretchFactor: 1,
			style: "inline",
			collapsed: true,
			controls: [
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					stretchFactor: 1,
					controls: [
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Parameters",
							controls: [
								{
									type: DefaultControls.LayoutBox,
									typeName: 'LayoutBox',
									margin: "large",
									controls: [
										{
											type: DefaultControls.CheckBox,
											typeName: 'CheckBox',
											name: "centrality_loops"
										},
										{
											type: DefaultControls.CheckBox,
											typeName: 'CheckBox',
											name: "centrality_normalize"
										},
										{
											type: DefaultControls.CheckBox,
											typeName: 'CheckBox',
											name: "centrality_show_table"
										},
										{
											type: DefaultControls.CheckBox,
											typeName: 'CheckBox',
											name: "centrality_show_plot"
										}
									]
								}
							]
						}
					]
				},
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					stretchFactor: 1,
					controls: [
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Measures",
							controls: [
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "centrality_Betweenness",
									label: "Betweenness"
								},
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "centrality_BetweennessRSP",
									label: "Betweenness RSP"
								},
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "centrality_Closeness",
									label: "Closeness"
								},
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "centrality_ClosenessIn",
									label: "Closeness In"
								},
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "centrality_ClosenessOut",
									label: "Closeness Out"
								},
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "centrality_Clustering",
									label: "Clustering"
								},
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "centrality_Diffusion",
									label: "Diffusion"
								},
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "centrality_InStrength",
									label: "In Strength"
								},
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "centrality_OutStrength",
									label: "Out Strength"
								}
							]
						}
					]
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Community",
			margin: "large",
			stretchFactor: 1,
			style: "inline",
			collapsed: true,
			controls: [
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					stretchFactor: 1,
					controls: [
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Methods",
							controls: [
								{
									type: DefaultControls.RadioButton,
									typeName: 'RadioButton',
									name: "community_methods_spinglass",
									optionName: "community_methods",
									optionPart: "spinglass"
								},
								{
									name: "community_methods_walktrap",
									type: DefaultControls.RadioButton,
									typeName: 'RadioButton',
									optionName: "community_methods",
									optionPart: "walktrap"
								},
								{
									name: "community_methods_fast_greedy",
									type: DefaultControls.RadioButton,
									typeName: 'RadioButton',
									optionName: "community_methods",
									optionPart: "fast_greedy"
								},
								{
									name: "community_methods_label_prop",
									type: DefaultControls.RadioButton,
									typeName: 'RadioButton',
									optionName: "community_methods",
									optionPart: "label_prop"
								},
								{
									name: "community_methods_infomap",
									type: DefaultControls.RadioButton,
									typeName: 'RadioButton',
									optionName: "community_methods",
									optionPart: "infomap"
								},
								{
									name: "community_methods_edge_betweenness",
									type: DefaultControls.RadioButton,
									typeName: 'RadioButton',
									optionName: "community_methods",
									optionPart: "edge_betweenness"
								},
								{
									name: "community_methods_leading_eigen",
									type: DefaultControls.RadioButton,
									typeName: 'RadioButton',
									optionName: "community_methods",
									optionPart: "leading_eigen"
								}
							]
						}
					]
				},
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					stretchFactor: 1,
					controls: [
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Parameters",
							controls: [
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "community_show_table",
									label: "Show table"
								},
								{
									type: DefaultControls.TextBox,
									typeName: 'TextBox',
									name: "community_gamma",
									format: FormatDef.number
								}
							]
						},
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Plot settings",
							controls: [
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "community_show_plot",
									label: "Show plot"
								}
							]
						}
					]
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Cliques",
			margin: "large",
			stretchFactor: 1,
			style: "inline",
			collapsed: true,
			controls: [
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					stretchFactor: 1,
					controls: [
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Parameters",
							controls: [
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "cliques_show_text",
									label: "Show text"
								},
								{
									type: DefaultControls.TextBox,
									typeName: 'TextBox',
									name: "cliques_size",
									format: FormatDef.number
								},
								{
									type: DefaultControls.TextBox,
									typeName: 'TextBox',
									name: "cliques_threshold",
									format: FormatDef.number
								}
							]
						}
					]
				},
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					stretchFactor: 1,
					controls: [
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Plot settings",
							controls: [
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "cliques_show_plot",
									label: "Show plot",
									controls: [
										{
											type: DefaultControls.TextBox,
											typeName: 'TextBox',
											name: "cliques_plot_cut",
											format: FormatDef.number,
											enable: "(cliques_show_plot)"
										},
										{
											type: DefaultControls.TextBox,
											typeName: 'TextBox',
											name: "cliques_plot_min_value",
											format: FormatDef.number,
											enable: "(cliques_show_plot)"
										},
										{
											type: DefaultControls.TextBox,
											typeName: 'TextBox',
											name: "cliques_plot_edge_label_size",
											format: FormatDef.number,
											enable: "(cliques_show_plot)"
										},
										{
											type: DefaultControls.TextBox,
											typeName: 'TextBox',
											name: "cliques_plot_node_size",
											format: FormatDef.number,
											enable: "(cliques_show_plot)"
										},
										{
											type: DefaultControls.TextBox,
											typeName: 'TextBox',
											name: "cliques_plot_node_label_size",
											format: FormatDef.number,
											enable: "(cliques_show_plot)"
										},
										{
											type: DefaultControls.ComboBox,
											typeName: 'ComboBox',
											name: "cliques_plot_layout",
											enable: "(cliques_show_plot)"
										}
									]
								}
							]
						}
					]
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Bootstrap",
			margin: "large",
			stretchFactor: 1,
			style: "inline",
			collapsed: true,
			controls: [
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					stretchFactor: 1,
					controls: [
						{
							type: DefaultControls.LayoutBox,
							typeName: 'LayoutBox',
							margin: "large",
							controls: [
								{
									type: DefaultControls.Label,
									typeName: 'Label',
									label: "Parameters",
									controls: [
										{
											type: DefaultControls.CheckBox,
											typeName: 'CheckBox',
											name: "bootstrap_show_text",
											label: "Show text"
										},
										{
											type: DefaultControls.TextBox,
											typeName: 'TextBox',
											name: "bootstrap_iteration",
											format: FormatDef.number
										},
										{
											type: DefaultControls.TextBox,
											typeName: 'TextBox',
											name: "bootstrap_level",
											format: FormatDef.number
										}
									]
								}
							]
						},
						{
							type: DefaultControls.LayoutBox,
							typeName: 'LayoutBox',
							margin: "large",
							controls: [
								{
									type: DefaultControls.Label,
									typeName: 'Label',
									label: "Methods",
									controls: [
										{
											type: DefaultControls.RadioButton,
											typeName: 'RadioButton',
											name: "bootstrap_method_stability",
											optionName: "bootstrap_method",
											optionPart: "stability",
											controls: [
												{
													type: DefaultControls.TextBox,
													typeName: 'TextBox',
													name: "bootstrap_range_low",
													format: FormatDef.number,
													enable: "(bootstrap_method_stability)"
												},
												{
													type: DefaultControls.TextBox,
													typeName: 'TextBox',
													name: "bootstrap_range_up",
													format: FormatDef.number,
													enable: "(bootstrap_method_stability)"
												}
											]
										},
										{
											type: DefaultControls.RadioButton,
											typeName: 'RadioButton',
											name: "bootstrap_method_threshold",
											optionName: "bootstrap_method",
											optionPart: "threshold",
											controls: [
												{
													type: DefaultControls.TextBox,
													typeName: 'TextBox',
													name: "bootstrap_threshold",
													format: FormatDef.number,
													enable: "(bootstrap_method_threshold)"
												}
											]
										}
									]
								}
							]
						}
					]
				},
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					stretchFactor: 1,
					controls: [
						{
							type: DefaultControls.LayoutBox,
							typeName: 'LayoutBox',
							margin: "large",
							controls: [
								{
									type: DefaultControls.Label,
									typeName: 'Label',
									label: "Plot settings",
									controls: [
										{
											type: DefaultControls.CheckBox,
											typeName: 'CheckBox',
											name: "bootstrap_show_plot",
											label: "Show plot",
											controls: [
												{
													type: DefaultControls.TextBox,
													typeName: 'TextBox',
													name: "bootstrap_plot_cut",
													format: FormatDef.number,
													enable: "(bootstrap_show_plot)"
												},
												{
													type: DefaultControls.TextBox,
													typeName: 'TextBox',
													name: "bootstrap_plot_min_value",
													format: FormatDef.number,
													enable: "(bootstrap_show_plot)"
												},
												{
													type: DefaultControls.TextBox,
													typeName: 'TextBox',
													name: "bootstrap_plot_edge_label_size",
													format: FormatDef.number,
													enable: "(bootstrap_show_plot)"
												},
												{
													type: DefaultControls.TextBox,
													typeName: 'TextBox',
													name: "bootstrap_plot_node_size",
													format: FormatDef.number,
													enable: "(bootstrap_show_plot)"
												},
												{
													type: DefaultControls.TextBox,
													typeName: 'TextBox',
													name: "bootstrap_plot_node_label_size",
													format: FormatDef.number,
													enable: "(bootstrap_show_plot)"
												},
												{
													type: DefaultControls.ComboBox,
													typeName: 'ComboBox',
													name: "bootstrap_plot_layout",
													enable: "(bootstrap_show_plot)"
												}
											]
										}
									]
								}
							]
						}
					]
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Comparison",
			margin: "large",
			stretchFactor: 1,
			style: "inline",
			collapsed: true,
			controls: [
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					stretchFactor: 1,
					controls: [
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Parameters",
							controls: [
								{
									type: DefaultControls.TextBox,
									typeName: 'TextBox',
									name: "compare_model1",
									format: FormatDef.number
								},
								{
									type: DefaultControls.TextBox,
									typeName: 'TextBox',
									name: "compare_model2",
									format: FormatDef.number
								},
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "compare_show_text",
									label: "Show text"
								},
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "compare_show_plot",
									label: "Show compare plot"
								},
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "compare_show_TNAplot",
									label: "Show compare TNA plot"
								},
								{
									type: DefaultControls.ComboBox,
									typeName: 'ComboBox',
									name: "compare_TNAPlot_type"
								},
								{
									type: DefaultControls.ComboBox,
									typeName: 'ComboBox',
									name: "compare_TNAPlot_population"
								},
								{
									type: DefaultControls.ComboBox,
									typeName: 'ComboBox',
									name: "compare_TNAPlot_method"
								}
							]
						}
					]
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Permutation",
			margin: "large",
			stretchFactor: 1,
			style: "inline",
			collapsed: true,
			controls: [
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					stretchFactor: 1,
					controls: [
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Parameters",
							controls: [
								{
									type: DefaultControls.TextBox,
									typeName: 'TextBox',
									name: "permutation_iter",
									format: FormatDef.number
								},
								{
									type: DefaultControls.TextBox,
									typeName: 'TextBox',
									name: "permutation_level",
									format: FormatDef.number
								},
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "permutation_paired"
								}
							]
						}
					]
				},
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					stretchFactor: 1,
					controls: [
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Print",
							controls: [
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "permutation_show_text"
								},
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "permutation_show_plot"
								}
							]
						}
					]
				}
			]
		}
	]
});

module.exports = { view : view, options: options };

},{}]},{},[1])(1)
});
