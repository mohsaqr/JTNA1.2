# ClusterTNA - Cluster-based TNA (replicates GroupTNA with automatic clustering)

ClusterTNAClass <- if (requireNamespace('jmvcore', quietly=TRUE)) R6::R6Class(
  "ClusterTNAClass",
  inherit = ClusterTNABase,
  private = list(
    .run = function() {
      library("tna")

      # Set instructions content
      self$results$instructions$setContent(
        '<div style="border: 2px solid #e6f4fe; border-radius: 15px; padding: 15px; background-color: #e6f4fe; margin-top: 10px;">
        <div style="text-align:justify;">
        <ul>
          <li>Data should be in <b>long format</b> with one row per event/action.</li>
          <li><b>Action</b>: Column containing the actions/states/events (required).</li>
          <li><b>Actor</b>: Column identifying individuals (required). Actors will be clustered based on their transition patterns.</li>
          <li><b>Time</b> or <b>Order</b>: For ordering events chronologically (optional).</li>
          <li>Set the <b>Number of Clusters (k)</b> and enable <b>Run Clustering</b> to cluster actors.</li>
          <li>Learn more: <a href="https://lamethods.org/book2/chapters/ch15-tna/ch15-tna.html" target="_blank">TNA Tutorial</a> | <a href="https://lamethods.org/book2/chapters/ch16-ftna/ch16-ftna.html" target="_blank">FTNA</a> | <a href="https://lamethods.org/book2/chapters/ch17-tna-clusters/ch17-tna-clusters.html" target="_blank">Group TNA</a></li>
        </ul>
        </div>
        </div>'
      )

      # Set clustering note
      self$results$clusteringNote$setContent(
        '<div style="border: 2px solid #e6f4fe; border-radius: 15px; padding: 15px; background-color: #e6f4fe; margin-top: 10px;">
        <p style="text-align:center; font-weight: bold; color: #1a5276; font-size: 14px;">
        ⏳ Note: Clustering may take time depending on your data size. Please be patient.
        </p>
        </div>'
      )

      # Check required variables
      if(is.null(self$options$buildModel_variables_long_action) ||
         is.null(self$options$buildModel_variables_long_actor)) {
        return()
      }

      # Check if user wants to run
      if(!isTRUE(self$options$clustering_run)) {
        self$results$errorText$setContent("Check 'Run Clustering Analysis' to start.")
        self$results$errorText$setVisible(TRUE)
        return()
      }

      # Check if model already exists in state (avoid recomputing)
      model <- self$results$buildModelContent$state

      if(is.null(model)) {
        # Only run clustering if model doesn't exist

        # Convert factors to character to preserve labels
        df <- data.frame(
          actor = as.character(self$data[[self$options$buildModel_variables_long_actor]]),
          action = as.character(self$data[[self$options$buildModel_variables_long_action]]),
          stringsAsFactors = FALSE
        )

        # Add time if provided
        if(!is.null(self$options$buildModel_variables_long_time)) {
          df$time <- self$data[[self$options$buildModel_variables_long_time]]
        }

        # Step 1: Prepare data
        args <- list(data = df, actor = "actor", action = "action")
        if(!is.null(self$options$buildModel_variables_long_time)) {
          args$time <- "time"
        }

        prepData <- suppressMessages(suppressWarnings(
          do.call(tna::prepare_data, args)
        ))

        # Step 2: Cluster using tna::cluster_sequences()
        seqData <- as.data.frame(prepData$sequence_data)

        # Use tna's cluster_sequences function with user-selected options
        k <- self$options$clustering_k
        dissimilarity <- self$options$clustering_dissimilarity
        method <- self$options$clustering_method

        clusters <- tna::cluster_sequences(
          data = seqData,
          k = k,
          dissimilarity = dissimilarity,
          method = method
        )

        # Step 3: Build group model
        model <- suppressMessages(suppressWarnings(
          tna::group_model(clusters, type = "relative")
        ))

        # Store model in state
        self$results$buildModelContent$setContent(model)
        self$results$buildModelContent$setState(model)
      }

      # Show clustering info (uses cached model)
      self$results$buildModelContent$setVisible(self$options$buildModel_show_matrix)
      self$results$buildModel_plot$setVisible(self$options$buildModel_show_plot)
      self$results$buildModel_histo$setVisible(self$options$buildModel_show_histo)
      self$results$buildModel_frequencies$setVisible(self$options$buildModel_show_frequencies)
      self$results$buildModel_mosaic$setVisible(self$options$buildModel_show_mosaic)

      ### Centrality
      if(!is.null(model) && (self$options$centrality_show_table || self$options$centrality_show_plot)) {
        centrality_loops <- self$options$centrality_loops
        centrality_normalize <- self$options$centrality_normalize

        vectorCharacter <- character(0)
        if(self$options$centrality_OutStrength) vectorCharacter <- append(vectorCharacter, "OutStrength")
        if(self$options$centrality_InStrength) vectorCharacter <- append(vectorCharacter, "InStrength")
        if(self$options$centrality_ClosenessIn) vectorCharacter <- append(vectorCharacter, "ClosenessIn")
        if(self$options$centrality_ClosenessOut) vectorCharacter <- append(vectorCharacter, "ClosenessOut")
        if(self$options$centrality_Closeness) vectorCharacter <- append(vectorCharacter, "Closeness")
        if(self$options$centrality_Betweenness) vectorCharacter <- append(vectorCharacter, "Betweenness")
        if(self$options$centrality_BetweennessRSP) vectorCharacter <- append(vectorCharacter, "BetweennessRSP")
        if(self$options$centrality_Diffusion) vectorCharacter <- append(vectorCharacter, "Diffusion")
        if(self$options$centrality_Clustering) vectorCharacter <- append(vectorCharacter, "Clustering")

        cent <- self$results$centralityTable$state

        if(length(vectorCharacter) > 0 && is.null(cent)) {
          tryCatch({
            cent <- tna::centralities(x=model, loops=centrality_loops, normalize=centrality_normalize, measures=vectorCharacter)
            self$results$centralityTable$setState(cent)
          }, error = function(e) {
            self$results$centralityTable$setNote(key = "error", note = paste("Error:", e$message))
          })
        }

        # Add columns
        self$results$centralityTable$addColumn(name="group", type="text")
        self$results$centralityTable$addColumn(name="state", type="text")
        for(measure in vectorCharacter) {
          self$results$centralityTable$addColumn(name=measure, type="number")
        }

        # Populate table
        if(!is.null(cent) && is.data.frame(cent) && nrow(cent) > 0) {
          for (i in 1:nrow(cent)) {
            rowValues <- list(group = as.character(cent[i, "group"]), state = as.character(cent[i, "state"]))
            for(measure in vectorCharacter) {
              if(measure %in% colnames(cent)) rowValues[[measure]] <- as.numeric(cent[i, measure])
            }
            self$results$centralityTable$addRow(rowKey=i, values=rowValues)
          }
        }

        self$results$centralityTitle$setVisible(self$options$centrality_show_table || self$options$centrality_show_plot)
        self$results$centrality_plot$setVisible(self$options$centrality_show_plot)
        self$results$centralityTable$setVisible(self$options$centrality_show_table)
      }

      ### Community
      if(!is.null(model) && isTRUE(self$options$community_show_plot)) {
        community_gamma <- as.numeric(self$options$community_gamma)
        methods <- self$options$community_methods

        coms <- self$results$community_plot$state
        if(is.null(coms)) {
          tryCatch({
            coms <- tna::communities(x=model, methods=methods, gamma=community_gamma)
            self$results$community_plot$setState(coms)
          }, error = function(e) {
            self$results$communityErrorText$setContent(paste("Error:", e$message))
            self$results$communityErrorText$setVisible(TRUE)
          })
        }

        self$results$community_plot$setVisible(self$options$community_show_plot)
        self$results$communityTitle$setVisible(self$options$community_show_plot)
      }

      ### Cliques
      if(!is.null(model) && (isTRUE(self$options$cliques_show_text) || isTRUE(self$options$cliques_show_plot))) {
        cliques_size <- as.numeric(self$options$cliques_size)
        cliques_threshold <- as.numeric(self$options$cliques_threshold)

        cliques <- self$results$cliques_multiple_plot$state
        if(is.null(cliques)) {
          cliques <- tna::cliques(x=model, size=cliques_size, threshold=cliques_threshold)
          self$results$cliques_multiple_plot$setState(cliques)
          if(isTRUE(self$options$cliques_show_text)) {
            self$results$cliquesContent$setContent(cliques)
          }
        }

        self$results$cliques_multiple_plot$setVisible(self$options$cliques_show_plot)
        self$results$cliquesContent$setVisible(self$options$cliques_show_text)
        self$results$cliquesTitle$setVisible(self$options$cliques_show_text || self$options$cliques_show_plot)
      }

      ### Bootstrap
      if(!is.null(model) && (isTRUE(self$options$bootstrap_show_table) || isTRUE(self$options$bootstrap_show_plot))) {
        bs <- self$results$bootstrap_plot$state
        if(is.null(bs)) {
          bs <- tna::bootstrap(
            x=model,
            iter=self$options$bootstrap_iteration,
            level=self$options$bootstrap_level,
            method=self$options$bootstrap_method,
            threshold=self$options$bootstrap_threshold,
            consistency_range=c(self$options$bootstrap_range_low, self$options$bootstrap_range_up)
          )
          self$results$bootstrap_plot$setState(bs)
        }

        # Populate bootstrap table
        if(!is.null(bs) && isTRUE(self$options$bootstrap_show_table)) {
          row_key <- 1
          max_rows <- self$options$bootstrap_table_max_rows
          show_all <- isTRUE(self$options$bootstrap_table_show_all)
          significant_only <- isTRUE(self$options$bootstrap_table_significant_only)

          for (group_name in names(bs)) {
            group_data <- bs[[group_name]]
            if (!is.null(group_data$summary) && nrow(group_data$summary) > 0) {
              summary_data <- group_data$summary
              # Sort by significance
              summary_data <- summary_data[order(-summary_data$sig, summary_data$p_value), ]

              # Filter for significant only if requested
              if (significant_only) {
                summary_data <- summary_data[summary_data$sig == TRUE, ]
              }

              if (nrow(summary_data) == 0) next

              for (i in 1:nrow(summary_data)) {
                # Check row limit unless show_all is enabled
                if (!show_all && row_key > max_rows) break

                row <- summary_data[i,]
                self$results$bootstrapTable$addRow(rowKey=row_key, values=list(
                  group = group_name,
                  from = as.character(row$from),
                  to = as.character(row$to),
                  weight = as.numeric(row$weight),
                  p_value = as.numeric(row$p_value),
                  cr_lower = as.numeric(row$cr_lower),
                  cr_upper = as.numeric(row$cr_upper),
                  ci_lower = as.numeric(row$ci_lower),
                  ci_upper = as.numeric(row$ci_upper),
                  significant = ifelse(row$sig, "Yes", "No")
                ))
                row_key <- row_key + 1
              }

              # Break outer loop if row limit reached
              if (!show_all && row_key > max_rows) break
            }
          }
        }

        self$results$bootstrap_plot$setVisible(self$options$bootstrap_show_plot)
        self$results$bootstrapTable$setVisible(self$options$bootstrap_show_table)
        self$results$bootstrapTitle$setVisible(self$options$bootstrap_show_plot || self$options$bootstrap_show_table)
      }

      ### Permutation
      if(!is.null(model) && (isTRUE(self$options$permutation_show_text) || isTRUE(self$options$permutation_show_plot))) {
        permTest <- self$results$permutation_plot$state
        if(is.null(permTest)) {
          permTest <- tna::permutation_test(
            x=model,
            iter=self$options$permutation_iter,
            paired=self$options$permutation_paired,
            level=self$options$permutation_level
          )
          self$results$permutation_plot$setState(permTest)
        }

        # Populate permutation table
        if(!is.null(permTest) && isTRUE(self$options$permutation_show_text)) {
          row_key <- 1
          for (comp_name in names(permTest)) {
            comp_data <- permTest[[comp_name]]
            if (!is.null(comp_data$edges$stats)) {
              stats_df <- comp_data$edges$stats
              for (i in 1:nrow(stats_df)) {
                self$results$permutationContent$addRow(rowKey=row_key, values=list(
                  group_comparison = comp_name,
                  edge_name = as.character(stats_df[i, "edge_name"]),
                  diff_true = as.numeric(stats_df[i, "diff_true"]),
                  effect_size = as.numeric(stats_df[i, "effect_size"]),
                  p_value = as.numeric(stats_df[i, "p_value"])
                ))
                row_key <- row_key + 1
              }
            }
          }
        }

        self$results$permutation_plot$setVisible(self$options$permutation_show_plot)
        self$results$permutationContent$setVisible(self$options$permutation_show_text)
        self$results$permutationTitle$setVisible(self$options$permutation_show_text || self$options$permutation_show_plot)
      }

      ### Sequences
      if(isTRUE(self$options$sequences_show_plot)) {
        self$results$sequences_plot$setVisible(TRUE)
      }

      ### Compare Sequences
      if(!is.null(model) && (isTRUE(self$options$compare_sequences_show_table) || isTRUE(self$options$compare_sequences_show_plot))) {
        compSeq <- self$results$compareSequences_plot$state
        if(is.null(compSeq)) {
          tryCatch({
            sub_range <- self$options$compare_sequences_sub_min:self$options$compare_sequences_sub_max
            compSeq <- tna::compare_sequences(
              x = model,
              sub = sub_range,
              min_freq = self$options$compare_sequences_min_freq,
              correction = self$options$compare_sequences_correction
            )

            # Remove patterns containing * (NAs)
            compSeq <- compSeq[!grepl("\\*", compSeq$pattern), ]

            # Sort by total frequency (sum of all freq_ columns)
            freqCols <- colnames(compSeq)[grep("^freq_", colnames(compSeq))]
            compSeq$total_freq <- rowSums(compSeq[, freqCols, drop=FALSE])
            compSeq <- compSeq[order(-compSeq$total_freq), ]

            # Keep only top 20
            if(nrow(compSeq) > 20) {
              compSeq <- compSeq[1:20, ]
            }
            compSeq$total_freq <- NULL

            self$results$compareSequences_plot$setState(compSeq)
          }, error = function(e) {
            self$results$errorText$setContent(paste("Compare Sequences Error:", e$message))
            self$results$errorText$setVisible(TRUE)
          })
        }

        # Show plot first, then table
        self$results$compareSequences_plot$setVisible(self$options$compare_sequences_show_plot)
        self$results$compareSequencesTitle$setVisible(self$options$compare_sequences_show_table || self$options$compare_sequences_show_plot)

        # Populate table
        if(!is.null(compSeq) && isTRUE(self$options$compare_sequences_show_table)) {
          # Get column names dynamically (freq_X, prop_X for each cluster)
          colNames <- colnames(compSeq)
          freqCols <- colNames[grep("^freq_", colNames)]
          propCols <- colNames[grep("^prop_", colNames)]

          # Add dynamic columns
          for(fc in freqCols) {
            self$results$compareSequencesTable$addColumn(name=fc, title=fc, type="integer")
          }
          for(pc in propCols) {
            self$results$compareSequencesTable$addColumn(name=pc, title=pc, type="number")
          }
          self$results$compareSequencesTable$addColumn(name="statistic", title="Statistic", type="number")
          self$results$compareSequencesTable$addColumn(name="p_value", title="p-value", type="number")

          # Add rows - extract vectors first to ensure atomic access
          patterns <- as.character(compSeq$pattern)
          statistics <- as.numeric(compSeq$statistic)
          p_values <- as.numeric(compSeq$p_value)

          for(i in 1:nrow(compSeq)) {
            patt <- patterns[i]
            rowValues <- list(
              pattern = patt,
              length = nchar(gsub("[^-]", "", patt)) + 1L
            )
            for(fc in freqCols) {
              rowValues[[fc]] <- as.integer(compSeq[[fc]])[i]
            }
            for(pc in propCols) {
              rowValues[[pc]] <- as.numeric(compSeq[[pc]])[i]
            }
            rowValues$statistic <- statistics[i]
            rowValues$p_value <- p_values[i]
            self$results$compareSequencesTable$addRow(rowKey=i, values=rowValues)
          }
        }

        self$results$compareSequencesTable$setVisible(self$options$compare_sequences_show_table)
      }

      ### Sequence Indices
      if(self$options$indices_show_table) {
        self$results$indicesTitle$setContent("Calculating Sequence Indices...")
        self$results$indicesTitle$setVisible(TRUE)

        tryCatch({
          # Prepare data for sequence indices
          action_col <- self$options$buildModel_variables_long_action
          actor_col <- self$options$buildModel_variables_long_actor
          time_col <- self$options$buildModel_variables_long_time
          order_col <- self$options$buildModel_variables_long_order

          # Check action_col is valid
          if(is.null(action_col) || length(action_col) == 0) {
            self$results$indicesTitle$setContent("Error: Action variable is required")
          } else {
            args_prepare_data <- list(
              data = self$data,
              action = action_col
            )
            if(!is.null(actor_col) && length(actor_col) > 0) {
              args_prepare_data$actor <- actor_col
            }
            if(!is.null(time_col) && length(time_col) > 0) {
              args_prepare_data$time <- time_col
            }
            if(!is.null(order_col) && length(order_col) > 0) {
              args_prepare_data$order <- order_col
            }

            dataForIndices <- do.call(prepare_data, args_prepare_data)

            if(is.null(dataForIndices)) {
              self$results$indicesTitle$setContent("Error: Could not prepare sequence data")
            } else {
              seq_data <- dataForIndices$sequence_data

              # Convert all columns to character (codyna requires character data)
              seq_data <- as.data.frame(lapply(seq_data, as.character), stringsAsFactors = FALSE)

              # Call sequence_indices
              fav_state <- self$options$indices_favorable
              has_favorable <- !is.null(fav_state) && length(fav_state) > 0 && !identical(fav_state, "")
              if (has_favorable) {
                indices <- codyna::sequence_indices(
                  data = seq_data,
                  favorable = fav_state,
                  omega = self$options$indices_omega
                )
              } else {
                indices <- codyna::sequence_indices(
                  data = seq_data,
                  omega = self$options$indices_omega
                )
              }

              # Add sequence ID
              indices$sequence_id <- 1:nrow(indices)

              # Add actor if provided
              if(!is.null(actor_col) && length(actor_col) > 0) {
                unique_actors <- unique(self$data[[actor_col]])
                indices$actor <- as.character(unique_actors)
              } else {
                indices$actor <- NA
              }

              # Add cluster assignments from the model
              if(!is.null(model) && !is.null(model$clusters) && !is.null(model$clusters$assignments)) {
                indices$cluster <- as.integer(model$clusters$assignments)
              } else {
                indices$cluster <- NA
              }

              # Apply row limit
              total_rows <- nrow(indices)
              if (!isTRUE(self$options$indices_table_show_all)) {
                max_rows <- self$options$indices_table_max_rows
                if (total_rows > max_rows) {
                  indices <- indices[1:max_rows, ]
                }
              }

              # Populate the table
              if(nrow(indices) > 0) {
                for(i in 1:nrow(indices)) {
                  self$results$indicesTable$addRow(rowKey=i, values=list(
                    sequence_id = indices$sequence_id[i],
                    actor = if(is.na(indices$actor[i])) "" else as.character(indices$actor[i]),
                    cluster = if(is.na(indices$cluster[i])) NA else as.integer(indices$cluster[i]),
                    valid_n = as.integer(indices$valid_n[i]),
                    unique_states = as.integer(indices$unique_states[i]),
                    longitudinal_entropy = round(indices$longitudinal_entropy[i], 3),
                    simpson_diversity = round(indices$simpson_diversity[i], 3),
                    mean_spell_duration = round(indices$mean_spell_duration[i], 3),
                    self_loop_tendency = round(indices$self_loop_tendency[i], 3),
                    transition_rate = round(indices$transition_rate[i], 3),
                    first_state = as.character(indices$first_state[i]),
                    last_state = as.character(indices$last_state[i]),
                    dominant_state = as.character(indices$dominant_state[i]),
                    complexity_index = round(indices$complexity_index[i], 3)
                  ))
                }

                # Show count in title
                if (nrow(indices) < total_rows) {
                  self$results$indicesTitle$setContent(paste("Showing", nrow(indices), "of", total_rows, "sequences"))
                } else {
                  self$results$indicesTitle$setContent(paste("Sequence Indices for", total_rows, "sequences"))
                }
              }

              self$results$indicesTable$setVisible(TRUE)
            }
          }
        }, error = function(e) {
          self$results$indicesTitle$setContent(paste("Sequence Indices error:", e$message))
        })
      }
    },

    # Plot functions
    .showBuildModelPlot = function(image, ...) {
      plotData <- self$results$buildModelContent$state
      if(is.null(plotData)) return(FALSE)

      if(length(plotData) == 1) {
        par(mfrow = c(1, 1))
      } else if(length(plotData) <= 4) {
        par(mfrow = c(2, 2))
      } else if(length(plotData) <= 6) {
        par(mfrow = c(2, 3))
      } else if(length(plotData) <= 9) {
        par(mfrow = c(3, 3))
      } else {
        row <- ceiling(sqrt(length(plotData)))
        column <- ceiling(length(plotData) / row)
        par(mfrow = c(row, column))
      }

      tryCatch({
        plot(x=plotData,
          cut=0.1,
          minimum=self$options$buildModel_plot_min_value,
          edge.label.cex=self$options$buildModel_plot_edge_label_size,
          node.width=self$options$buildModel_plot_node_size,
          label.cex=self$options$buildModel_plot_node_label_size,
          layout=self$options$buildModel_plot_layout
        )
      }, error = function(e) {
        self$results$errorText$setContent(paste0("Plot error: ", e$message))
        self$results$errorText$setVisible(TRUE)
      })
      TRUE
    },

    .showBuildModelHisto = function(image, ...) {
      plotData <- self$results$buildModelContent$state
      if(is.null(plotData) || !self$options$buildModel_show_histo) return(FALSE)

      if(length(plotData) <= 4) {
        par(mfrow = c(2, 2))
      } else {
        par(mfrow = c(ceiling(sqrt(length(plotData))), ceiling(sqrt(length(plotData)))))
      }

      for(i in 1:length(plotData)) {
        group_name <- names(plotData)[i]
        if(is.null(group_name)) group_name <- paste("Cluster", i)
        hist(x=plotData[[i]], main=paste("Histogram -", group_name), xlab="Edge Weights", ylab="Frequency")
      }
      TRUE
    },

    .showBuildModelFrequencies = function(image, ...) {
      plotData <- self$results$buildModelContent$state
      if(is.null(plotData) || !self$options$buildModel_show_frequencies) return(FALSE)
      tryCatch({
        p <- tna::plot_frequencies(x=plotData)
        if(!is.null(p)) print(p)
      }, error = function(e) {
        hist(x=plotData, main="Frequencies Plot", xlab="Edge Weights", ylab="Frequency")
      })
      TRUE
    },

    .showBuildModelMosaic = function(image, ...) {
      plotData <- self$results$buildModelContent$state
      if(is.null(plotData) || !self$options$buildModel_show_mosaic) return(FALSE)
      p <- tna::plot_mosaic(x=plotData, digits=self$options$buildModel_digits)
      print(p)
      TRUE
    },

    .showCentralityPlot = function(image, ...) {
      plotData <- self$results$centralityTable$state
      if(is.null(plotData) || !self$options$centrality_show_plot) return(FALSE)
      print(plot(plotData))
      TRUE
    },

    .showCommunityPlot = function(image, ...) {
      plotData <- self$results$community_plot$state
      if(is.null(plotData) || !self$options$community_show_plot) return(FALSE)

      if(length(plotData) <= 4) {
        par(mfrow = c(2, 2))
      } else {
        par(mfrow = c(ceiling(sqrt(length(plotData))), ceiling(sqrt(length(plotData)))))
      }
      plot(x=plotData, method=self$options$community_methods)
      TRUE
    },

    .showCliquesPlot1 = function(image, ...) { private$.showCliquesPlotN(1) },
    .showCliquesPlot2 = function(image, ...) { private$.showCliquesPlotN(2) },
    .showCliquesPlot3 = function(image, ...) { private$.showCliquesPlotN(3) },
    .showCliquesPlot4 = function(image, ...) { private$.showCliquesPlotN(4) },
    .showCliquesPlot5 = function(image, ...) { private$.showCliquesPlotN(5) },
    .showCliquesPlot6 = function(image, ...) { private$.showCliquesPlotN(6) },

    .showCliquesPlotN = function(n) {
      plotData <- self$results$cliques_multiple_plot$state
      if(is.null(plotData) || !self$options$cliques_show_plot) return(FALSE)
      if(lengths(plotData[1]) < n) {
        self$results$cliques_multiple_plot[[paste0("cliques_plot", n)]]$setVisible(FALSE)
        return(FALSE)
      }

      len <- length(plotData)
      par(mfrow = c(ceiling(sqrt(len)), ceiling(sqrt(len))))
      plot(x=plotData, ask=FALSE, first=n, n=1,
        cut=self$options$cliques_plot_cut,
        minimum=self$options$cliques_plot_min_value,
        edge.label.cex=self$options$cliques_plot_edge_label_size,
        node.width=self$options$cliques_plot_node_size,
        label.cex=self$options$cliques_plot_node_label_size,
        layout=self$options$cliques_plot_layout
      )
      TRUE
    },

    .showBootstrapPlot = function(image, ...) {
      plotData <- self$results$bootstrap_plot$state
      if(is.null(plotData) || !self$options$bootstrap_show_plot) return(FALSE)

      if(length(plotData) <= 4) {
        par(mfrow = c(2, 2))
      } else {
        par(mfrow = c(ceiling(sqrt(length(plotData))), ceiling(sqrt(length(plotData)))))
      }
      plot(x=plotData, cut=0.01)
      TRUE
    },

    .showPermutationPlot = function(image, ...) {
      plotData <- self$results$permutation_plot$state
      if(is.null(plotData) || !self$options$permutation_show_plot) return(FALSE)

      if(length(plotData) <= 4) {
        par(mfrow = c(2, 2))
      } else {
        par(mfrow = c(ceiling(sqrt(length(plotData))), ceiling(sqrt(length(plotData)))))
      }
      plot(x=plotData)
      TRUE
    },

    .showSequencesPlot = function(image, ...) {
      if(!self$options$sequences_show_plot) return(FALSE)
      tna_data <- self$results$buildModelContent$state
      if(is.null(tna_data)) return(FALSE)

      tryCatch({
        p <- tna::plot_sequences(
          x = tna_data,
          type = self$options$sequences_type,
          scale = self$options$sequences_scale,
          geom = self$options$sequences_geom,
          include_na = self$options$sequences_include_na,
          tick = self$options$sequences_tick
        )
        print(p)
      }, error = function(e) {
        plot(1, type="n", main="Sequence Error", sub=e$message)
      })
      TRUE
    },

    .showCompareSequencesPlot = function(image, ...) {
      if(!self$options$compare_sequences_show_plot) return(FALSE)
      plotData <- self$results$compareSequences_plot$state
      if(is.null(plotData)) return(FALSE)

      tryCatch({
        p <- plot(plotData)
        # Make text larger
        p <- p + ggplot2::theme(
          text = ggplot2::element_text(size = 14),
          axis.text = ggplot2::element_text(size = 12),
          axis.title = ggplot2::element_text(size = 14),
          legend.text = ggplot2::element_text(size = 12),
          legend.title = ggplot2::element_text(size = 14),
          strip.text = ggplot2::element_text(size = 12)
        )
        print(p)
      }, error = function(e) {
        plot(1, type="n", main="Compare Sequences Error", sub=e$message)
      })
      TRUE
    }
  )
)
